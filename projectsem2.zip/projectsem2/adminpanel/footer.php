
<footer class="footer">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <p>&copy; <?php echo date('Y'); ?> Preclinic Admin Panel. All Rights Reserved.</p>
            </div>
        </div>
    </div>
</footer>

<style>
    .footer {
        background: #f8f9fa;
        padding: 10px 0;
        bottom: 0;
        width: 100%;
        text-align: center;
        font-size: 14px;
        color: #333;
        border-top: 1px solid #ddd;
    }
</style>
<div class="sidebar-overlay" data-reff=""></div>
    <script src="assets/js/jquery-3.2.1.min.js"></script>
	<script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/jquery.slimscroll.js"></script>
    <script src="assets/js/Chart.bundle.js"></script>
    <script src="assets/js/chart.js"></script>
    <script src="assets/js/app.js"></script>