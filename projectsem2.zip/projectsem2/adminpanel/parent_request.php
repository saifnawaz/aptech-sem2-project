<?php include('connection.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Hospital Requests - Admin</title>
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <style>
        body { padding: 20px; }
        .table th { background-color: #009efb; color: white; }
    </style>
</head>
<body>
<?php include('asside.php'); ?>

<div class="container mt-5">
    <h2 class="text-center"><span style="color:#009efb">H</span>ospital <span style="color:#009efb">R</span>egistration Requests</h2>

    <div class="table-responsive mt-4">
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>Hospital Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Address</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $query = mysqli_query($conn, "SELECT * FROM hospital_requests WHERE status = 'Pending'");
                while ($row = mysqli_fetch_assoc($query)) {
                ?>
<tr>
    <td><?php echo $row['name']; ?></td>
    <td><?php echo $row['email']; ?></td>
    <td><?php echo $row['phone']; ?></td>
    <td><?php echo $row['address']; ?></td>
    <td><?php echo $row['status']; ?></td> <!-- 👈 Showing status here -->
    <td>
        <form method="post">
            <input type="hidden" name="request_id" value="<?php echo $row['id']; ?>">
            <input type="hidden" name="name" value="<?php echo $row['name']; ?>">
            <input type="hidden" name="email" value="<?php echo $row['email']; ?>">
            <input type="hidden" name="phone" value="<?php echo $row['phone']; ?>">
            <input type="hidden" name="address" value="<?php echo $row['address']; ?>">

            <button type="submit" name="status" value="Approved" class="btn btn-success btn-sm">Approve</button>
            <button type="submit" name="status" value="Rejected" class="btn btn-danger btn-sm">Reject</button>
            <input type="hidden" name="update_status" value="1">
        </form>
    </td>
</tr>



                      <?php
include('connection.php'); 

if (isset($_POST['submit'])) {
    // Sanitize input
    $hosname = mysqli_real_escape_string($conn, $_POST['hosname']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $number = mysqli_real_escape_string($conn, $_POST['phone']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $pass = mysqli_real_escape_string($conn, $_POST['password']);

    // Step 1: Insert into users table
    $insert_user = mysqli_query($conn, 
        "INSERT INTO users (name, email, password, role) 
         VALUES ('$hosname', '$email', '$pass', 'hospital')");

    if ($insert_user) {
        // Step 2: Get inserted user ID
        $user_id = mysqli_insert_id($conn);

        // Step 3: Now insert into hospitals table
        $insert_hospital = mysqli_query($conn, 
            "INSERT INTO hospitals (user_id, hospital_name, address, phone, email, password, role, status, created_at)
             VALUES ('$user_id', '$hosname', '$address', '$number', '$email', '$pass', 'hospital', 'Pending', NOW())");

        if ($insert_hospital) {
            echo "<script>alert('Hospital request submitted successfully!'); window.location.href='index.php';</script>";
        } else {
            echo "Hospital insert error: " . mysqli_error($conn);
        }
    } else {
        echo "User insert error: " . mysqli_error($conn);
    }
}
?>

                    </td>
                </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>

<?php
if (isset($_POST['update_status'])) {
    $request_id = mysqli_real_escape_string($conn, $_POST['request_id']);
    $status = mysqli_real_escape_string($conn, $_POST['status']);

    if ($status == "Approved") {
        // Sanitize all input fields
        $hospital_name = mysqli_real_escape_string($conn, $_POST['name']);
        $email = mysqli_real_escape_string($conn, $_POST['email']);
        $phone = mysqli_real_escape_string($conn, $_POST['phone']);
        $address = mysqli_real_escape_string($conn, $_POST['address']);

        // Optional: You can assign a dummy user_id (if not handled elsewhere)
        $user_id = 0;

        // Password: assign a default password or use random generation
        $default_pass = password_hash("hospital123", PASSWORD_DEFAULT);

        // Role can be 'hospital', status is 'Active' or 'Approved'
        $role = 'hospital';
        $final_status = 'Active';

        // Insert into hospitals table
        $insert = "INSERT INTO hospitals (hospital_name, address, phone, email, password, role, status, created_at)
                   VALUES ( '$hospital_name', '$address', '$phone', '$email', '$default_pass', '$role', '$final_status', NOW())";

        if (mysqli_query($conn, $insert)) {
            // Delete from hospital_requests table
            mysqli_query($conn, "DELETE FROM hospital_requests WHERE id='$request_id'");
            echo "<script>alert('Hospital Approved and Added Successfully');</script>";
          exit(); 
        } else {
            echo "<script>alert('Error adding hospital: " . mysqli_error($conn) . "');</script>";
        }

    } elseif ($status == "Rejected") {
        // Only delete if rejected
        mysqli_query($conn, "DELETE FROM hospital_requests WHERE id='$request_id'");
        echo "<script>alert('Hospital Rejected and Deleted'); location.reload();</script>";
    }
}

?>

<?php include('footer.php'); ?>
</body>
</html>

