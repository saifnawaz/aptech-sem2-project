<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Hospital Login - COVID Booking</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            font-family: 'Roboto', sans-serif;
            box-sizing: border-box;
        }

        body {
            background-color: #121212;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            color: #ffffff;
        }

        .login-container {
            background-color: #1e1e1e;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 0 20px rgba(0,0,0,0.5);
            width: 350px;
        }

        .login-container h2 {
            text-align: center;
            margin-bottom: 30px;
            color: #00bcd4;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            font-size: 14px;
            margin-bottom: 8px;
            color: #ccc;
        }

        .form-group input {
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 6px;
            background-color: #2c2c2c;
            color: #fff;
        }

        .form-group input:focus {
            outline: none;
            background-color: #3a3a3a;
        }

        .btn {
            width: 100%;
            padding: 10px;
            background-color: #00bcd4;
            color: #fff;
            border: none;
            border-radius: 6px;
            font-weight: bold;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        .btn:hover {
            background-color: #0097a7;
        }

        .extra-links {
            text-align: center;
            margin-top: 15px;
        }

        .extra-links a {
            color: #90caf9;
            font-size: 14px;
            text-decoration: none;
        }

        .extra-links a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <form class="login-container" action="hospital_login.php" method="POST">
        <h2>Hospital Login</h2>

        <div class="form-group">
            <label for="email">Hospital Email</label>
            <input type="email" id="email" name="email" required placeholder="Enter hospital email">
        </div>

        <div class="form-group">
            <label for="password">Password</label>
            <input type="password" id="password" name="password" required placeholder="Enter password">
        </div>

        <button class="btn" type="submit">Login</button>

        <div class="extra-links">
            <a href="#">Forgot Password?</a>
        </div>
    </form>
</body>
</html>
