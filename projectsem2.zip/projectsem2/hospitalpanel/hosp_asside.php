<?php 
session_start();

if (!isset($_SESSION['username']) || $_SESSION['userrole'] != 'hospital') {
    echo "<script>location.assign('hospital_login.php');</script>";
    exit;
}
?> 

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
  <title>Hospital Dashboard</title>
  <link rel="shortcut icon" href="assets/img/favicon.ico">
  <link rel="stylesheet" href="assets/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/css/font-awesome.min.css">
  <link rel="stylesheet" href="assets/css/style.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
</head>
<body>

<!-- Header -->
<div class="header">
  <div class="header-left">
    <a href="index.php" class="logo">
      <img src="assets/img/logo.png" width="35" height="35" alt=""> <span>Hospital Panel</span>
    </a>
  </div>
  <a id="toggle_btn" href="javascript:void(0);"><i class="fa fa-bars"></i></a>
  <a id="mobile_btn" class="mobile_btn float-left" href="#sidebar"><i class="fa fa-bars"></i></a>

  <ul class="nav user-menu float-right">
    <!-- Notifications -->
    <li class="nav-item dropdown d-none d-sm-block">
      <a href="#" class="dropdown-toggle nav-link" data-toggle="dropdown"><i class="fa fa-bell-o"></i> 
        <span class="badge badge-pill bg-danger float-right">3</span>
      </a>
      <div class="dropdown-menu notifications">
        <div class="topnav-dropdown-header"><span>Notifications</span></div>
        <div class="drop-scroll">
          <ul class="notification-list">
            <li class="notification-message">
              <a href="#">
                <div class="media">
                  <span class="avatar"><img alt="John Doe" src="assets/img/user.jpg"></span>
                  <div class="media-body">
                    <p class="noti-details"><b>Admin</b> sent a reminder</p>
                    <p class="noti-time"><span class="notification-time">2 mins ago</span></p>
                  </div>
                </div>
              </a>
            </li>
          </ul>
        </div>
        <div class="topnav-dropdown-footer"><a href="#">View all</a></div>
      </div>
    </li>

    <!-- User Profile -->
    <li class="nav-item dropdown has-arrow">
      <a href="#" class="dropdown-toggle nav-link user-link" data-toggle="dropdown">
        <span class="user-img">
          <img class="rounded-circle" src="assets/img/user.jpg" width="24" alt="User">
          <span class="status online"></span>
        </span>
        <span><?php echo $_SESSION['username']; ?></span>
      </a>
      <div class="dropdown-menu">
        <a class="dropdown-item" href="logout.php">Logout</a>
      </div>
    </li>
  </ul>
</div>
<!-- /Header -->

<!-- Sidebar -->
<div class="sidebar" id="sidebar">
  <div class="sidebar-inner slimscroll">
    <div id="sidebar-menu" class="sidebar-menu">
      <ul>
        <li class="menu-title">Main</li>
        <li class="active">
          <a href="index.php"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a>
        </li>
        <li>
          <a href="view_parent-reqhos.php?hosid=<?php echo $_SESSION['user_id']; ?>"><i class="fa fa-check-circle"></i> <span>Parent Requests</span></a>
        </li>
        <li>
          <a href="completed_vaccines.php"><i class="fa fa-calendar-check-o"></i> <span>Completed Vaccines</span></a>
        </li>
        <li class="submenu">
          <a href="#"><i class="fa fa-file-text"></i> <span>Vaccination Reports</span> <span class="menu-arrow"></span></a>
          <ul style="display: none;">
            <li><a href="add-vaccine.php">Add Vaccine</a></li>
            <li><a href="view-hosvaccine.php">View Vaccine</a></li>
          </ul>
        </li>
        <li>
          <a href="logout.php" class="text-danger"><i class="fa fa-sign-out"></i> <span>Logout</span></a>
        </li>
      </ul>
    </div>
  </div>
</div>
<!-- /Sidebar -->

</body>
</html>
