<?php
// hospitalpanel/index.php
session_start();
include('../connection.php');
include('includes/header.php');
include('hosp_asside.php');

// Optional: session check
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Hospital Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-4">
    <h2 class="mb-4">Welcome to Hospital Dashboard</h2>

    <!-- Patient List -->
    <div class="card mt-4">
        <div class="card-header bg-primary text-white">Approved Patients</div>
        <div class="card-body">
            <?php
            $sql = "SELECT * FROM patients WHERE covid_test_status = 'approved'";
            $result = mysqli_query($conn, $sql);

            if (mysqli_num_rows($result) > 0) {
                echo "<table class='table table-striped'><thead><tr>
                        <th>ID</th><th>Name</th><th>DOB</th><th>Gender</th><th>Blood Group</th><th>Conditions</th>
                      </tr></thead><tbody>";
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>
                            <td>{$row['id']}</td>
                            <td>{$row['first_name']} {$row['last_name']}</td>
                            <td>{$row['dob']}</td>
                            <td>{$row['gender']}</td>
                            <td>{$row['blood_group']}</td>
                            <td>{$row['medical_conditions']}</td>
                          </tr>";
                }
                echo "</tbody></table>";
            } else {
                echo "<p>No approved patients found.</p>";
            }
            ?>
        </div>
    </div>

    <!-- Request Test/Vaccine -->
    <div class="card mt-4">
        <div class="card-header bg-success text-white">Request Test / Vaccination</div>
        <div class="card-body">
            <form action="request_patient.php" method="POST">
                <div class="mb-3">
                    <label for="patient_id" class="form-label">Patient ID</label>
                    <input type="number" name="patient_id" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label for="request_type" class="form-label">Request Type</label>
