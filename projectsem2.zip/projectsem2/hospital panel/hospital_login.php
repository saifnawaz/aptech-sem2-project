<?php
session_start();
require_once '../db.php';

$login_success = false;
$error_message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    $stmt = $conn->prepare("SELECT * FROM hospitals WHERE email = ?");
    $stmt->execute([$email]);
    $hospital = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($hospital && $hospital['password'] === $password) {
        $_SESSION['hospital_id'] = $hospital['id'];
        $_SESSION['hospital_name'] = $hospital['hospital_name'];
        $login_success = true;
    } else {
        $error_message = 'Invalid email or password';
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Hospital Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f2f2f2;
            padding: 50px;
        }
        .box {
            width: 350px;
            margin: auto;
            background: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px #aaa;
        }
        input, button {
            width: 100%;
            padding: 10px;
            margin-top: 15px;
        }
        .error {
            color: red;
            margin-top: 10px;
            text-align: center;
        }
    </style>
</head>
<body>

<div class="box">
    <h2>Hospital Login</h2>
    <form method="POST" onsubmit="return handleLogin(event)">
        <input type="email" name="email" placeholder="Email" required />
        <input type="password" name="password" placeholder="Password" required />
        <button type="submit">Login</button>
    </form>

    <?php if (!empty($error_message)): ?>
        <div class="error"><?= $error_message ?></div>
    <?php endif; ?>
</div>

<?php if ($login_success): ?>
<script>
    alert("✅ Login Successful!");
    window.location.href = "hosp_index.php";
</script>
<?php endif; ?>

<script>
function handleLogin(e) {
    // let PHP handle the login
    return true;
}
</script>

</body>
</html>
